﻿using Microsoft.IdentityModel.Clients.ActiveDirectory;
using Microsoft.Recognizers.Text.DataTypes.TimexExpression;
using MongoDB.Bson;
using MongoDB.Driver;
using MongoDB.Driver.Core.Operations;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel.Channels;
using System.Threading.Tasks;

namespace QnABot.DBCon
{
    public class DBController
    {
        public void storeConversation(string username, string conversation, string timestamp)
        {
            try
            {
                DBConn connection = new DBConn();
                IMongoDatabase db = connection.getConnection();
                string id=null;
                IMongoCollection<BsonDocument> coll = db.GetCollection<BsonDocument>("Test");
                var filter = Builders<BsonDocument>.Filter.Eq("_id", $"{username}");
                var cursor = coll.Find(filter).ToCursor();
                foreach (var document in cursor.ToEnumerable())
                {
                    id = document["_id"].ToString();
                }
                if (id == null)
                {
                    var doc = new BsonDocument
                            {
                                {"_id",$"{username}"},
                                { "Name",$"{username }" },
                                { "Messages",
                                    new BsonArray{ 
                                        new BsonDocument{
                                            { "Message", $"{conversation}" },
                                            { "Timestamp",$"{timestamp}"}
                                        }
                                       
                                    }
                                },
                                
                            };
                    coll.InsertOne(doc);
                }
                else
                {
                    var update = Builders<BsonDocument>.Update.AddToSet("Messages", new BsonDocument {{"Message",$"{conversation}"},{"Timestamp",$"{ timestamp}"} } );
                    coll.UpdateOne(filter, update);
                }
            }
            catch(Exception e) {
                Console.WriteLine(e.Message);
            }

        }
    }
    
}
