﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Authentication;
using System.Threading.Tasks;
using Microsoft.Azure.Cosmos;
using MongoDB.Bson;
using MongoDB.Driver;

namespace QnABot.DBCon
{
    public class DBConn
    {
        public  IMongoDatabase getConnection()
        {
            string connectionString =
            @"mongodb://botaxa-db:6biQE3yOUfn6Uckf1Rnx9Ad8a7hy0lcpQi8eMFzCvznR4T3wpX4AdR5rR7GhRRuLsHKKkDkRIZkEeR2QKuk2vA==@botaxa-db.mongo.cosmos.azure.com:10255/?ssl=true&replicaSet=globaldb&maxIdleTimeMS=120000&appName=@botaxa-db@";
            MongoClientSettings settings = MongoClientSettings.FromUrl(
              new MongoUrl(connectionString)
            );
            settings.SslSettings = 
            new SslSettings() { EnabledSslProtocols = SslProtocols.Tls12 };
            settings.RetryWrites = false;
            var mongoClient = new MongoClient(settings);
            IMongoDatabase db =  mongoClient.GetDatabase("Test1");

          
            return db;
        }
      
    }
}
