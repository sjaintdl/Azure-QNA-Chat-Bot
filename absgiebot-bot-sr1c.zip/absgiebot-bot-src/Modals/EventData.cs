﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Newtonsoft.Json;
namespace QnABot.Modals
{
    public class EventData
    {

       [JsonProperty(PropertyName = "UserId")]
        public string UserId { get; set; }

        public DateTime Timestamp { get; set; }

        public ICollection<Conversation> Conversations { get; set; }
       
        public ICollection<UserFeedback> UserFeedbacks { get; set; }
    }

    public class Conversation
    {
        public DateTime Timestamp { get; set; }

        public string UserResponse { get; set; }

        public string BotResponse { get; set; }
    }

    public class UserFeedback
    {
        public DateTime Timestamp { get; set; }

        public string UserResponse { get; set; }

        public string BotResponse { get; set; }

        public string feedback { get; set; }

    }
}
