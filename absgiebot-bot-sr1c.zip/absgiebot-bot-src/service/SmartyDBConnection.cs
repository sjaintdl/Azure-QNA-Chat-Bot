﻿using Microsoft.Azure.Cosmos;
using Microsoft.Azure.Documents.Client;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QnABot.service
{
    public class SmartyDBConnection
    {
        private readonly CosmosClient _cosmosClient;
        private readonly Microsoft.Azure.Cosmos.Database _database;
        private readonly Container _container;
        private readonly DocumentClient _client;

        public SmartyDBConnection(IConfiguration configuration)
        {
            _cosmosClient = new CosmosClient(configuration["CosmosDbEndpoint"], configuration["CosmosDbAuthKey"]);
            _database = _cosmosClient.GetDatabase(configuration["CosmosDbDatabaseId"]);
            _container = _database.GetContainer(configuration["CosmosDbDatabaseId"]);
        }

    }
}
