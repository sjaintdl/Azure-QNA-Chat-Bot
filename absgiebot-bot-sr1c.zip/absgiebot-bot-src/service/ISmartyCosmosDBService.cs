﻿using QnABot.Modals;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QnABot.Data
{
    interface ISmartyCosmosDBService
    {
        Task<IEnumerable<EventData>> GetItemsAsync(string query);
        Task<EventData> GetItemAsync(string id);
        Task AddItemAsync(EventData item);
        Task UpdateItemAsync(string id, EventData item);
        Task DeleteItemAsync(string id);
    }
}
