﻿using QnABot.Data;
using QnABot.Modals;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QnABot.service
{
    public class SmartyCosmosDBService : ISmartyCosmosDBService
    {
        public SmartyCosmosDBService()
        {

        }

        public Task AddItemAsync(EventData item)
        {
            
            throw new NotImplementedException();
        }

        public Task DeleteItemAsync(string id)
        {
            throw new NotImplementedException();
        }

        public Task<EventData> GetItemAsync(string id)
        {
            throw new NotImplementedException();
        }

        public Task<IEnumerable<EventData>> GetItemsAsync(string query)
        {
            throw new NotImplementedException();
        }

        public Task UpdateItemAsync(string id, EventData item)
        {
            throw new NotImplementedException();
        }
    }
}
