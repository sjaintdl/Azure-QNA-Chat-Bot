﻿// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Bot.Builder.AI.QnA;
using Microsoft.Bot.Builder.AI.QnA.Dialogs;
using Microsoft.Bot.Builder.Dialogs;
using System.Linq;
using Microsoft.Bot.Builder.Dialogs.Choices;
using Microsoft.Bot.Builder;
using Microsoft.Bot.Schema;

namespace Microsoft.BotBuilderSamples.Dialog
{
    /// <summary>
    /// This is an example root dialog. Replace this with your applications.
    /// </summary>
    public class RootDialog : ComponentDialog
    {
        /// <summary>
        /// QnA Maker initial dialog
        /// </summary>
        private const string InitialDialog = "initial-dialog";

        /// <summary>
        /// Initializes a new instance of the <see cref="RootDialog"/> class.
        /// </summary>
        /// <param name="services">Bot Services.</param>
        public RootDialog(IBotServices services)
            : base("root") { 

            AddDialog(new QnAMakerBaseDialog(services));

            // Adding Waterfall Dialog
            AddDialog(new WaterfallDialog(nameof(WaterfallDialog), new WaterfallStep[]{
                InitialStepAsync,
                RecognizeGreetingAndChitChatStepAsync,
                FinalStepAsync,
            }));

            // The initial child Dialog to run.
            InitialDialogId = nameof(WaterfallDialog);
        }

        private async Task<DialogTurnResult> InitialStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            if (stepContext.Context.Activity.Text.ToLower().Contains("oui") || stepContext.Context.Activity.Text.ToLower().Contains("non"))
            {
                await FeedbackStepAsync(stepContext.Context, cancellationToken);
                return await stepContext.CancelAllDialogsAsync();
            }
            return await stepContext.BeginDialogAsync(nameof(QnAMakerDialog), null, cancellationToken);
        }

        private async Task<DialogTurnResult> RecognizeGreetingAndChitChatStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {

            return await stepContext.NextAsync();
        }

        private async Task<DialogTurnResult> FinalStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            // TODO: Save only All chats insated of feedback in cosmosDB using service

            await SendSuggestedActionsAsync(stepContext.Context, cancellationToken);
            return await stepContext.EndDialogAsync() ;
        }

        private async Task FeedbackStepAsync(ITurnContext turnContext, CancellationToken cancellationToken)
        {
            // TODO: Save only the feedback in cosmosDB using service
             await turnContext.SendActivityAsync("Hello");
        }



        private static async Task SendSuggestedActionsAsync(ITurnContext turnContext, CancellationToken cancellationToken)
        {
            if (!turnContext.Activity.Text.ToLower().Contains("oui") || !turnContext.Activity.Text.ToLower().Contains("non"))
            {
                List<CardAction> actions = new List<CardAction>();
                actions.Add(new CardAction()
                {
                    DisplayText = "👍",
                    Text = "👍",
                    Title = "👍",
                    Value = "Oui",
                    Type = ActionTypes.ImBack
                });
                actions.Add(new CardAction()
                {
                    DisplayText = "👎",
                    Text = "👎",
                    Title = "👎",
                    Value = "Non",
                    Type = ActionTypes.ImBack
                });

                SuggestedActions suggestedActions = new SuggestedActions()
                {
                    Actions = actions
                };
                var reply = turnContext.Activity.CreateReply("Souhaitez - vous donner votre avis ?");
                reply.SuggestedActions = suggestedActions;
                await turnContext.SendActivityAsync(reply, cancellationToken);
            }
        }

    }
}
