﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Authentication;
using System.Threading.Tasks;
using Microsoft.Azure.Cosmos;
using MongoDB.Bson;
using MongoDB.Driver;

namespace QnABot.DBCon
{
    public class DBConn
    {
        public  IMongoDatabase getConnection()
        {
          string connectionString = 
  @"mongodb://axadb011:gQeM6XoYevoXVFx3ZLjpXFWerUrBPmW9w0ghNzn1uFeoSnHjtT9tjHOfWoNgPRkML6PsBan77RO50lrzRMvITw==@axadb011.mongo.cosmos.azure.com:10255/?ssl=true&replicaSet=globaldb&maxIdleTimeMS=120000&appName=@axadb011@";
MongoClientSettings settings = MongoClientSettings.FromUrl(
  new MongoUrl(connectionString)
);
            settings.SslSettings = 
            new SslSettings() { EnabledSslProtocols = SslProtocols.Tls12 };
            settings.RetryWrites = false;
            var mongoClient = new MongoClient(settings);
            IMongoDatabase db =  mongoClient.GetDatabase("Test1");

          
            return db;
        }
      
    }
}
